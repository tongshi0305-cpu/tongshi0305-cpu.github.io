﻿param([Parameter(Mandatory=$true)][string]$Executable)
$ErrorActionPreference = 'Stop'
$programPath = (Resolve-Path -LiteralPath $Executable).Path
Push-Location -LiteralPath (Join-Path $PSScriptRoot 'quickstart')
try {
    New-Item -ItemType Directory -Path rerun -Force | Out-Null
    $answers = @'
1
11
CG
inputs/HTPB_cis_AA_500frames.xyz
100
inputs/mapping_HTPB_cis.json
1
rerun/HTPB_cis_COM.xyz
12
rerun/HTPB_cis_COM.xyz
rerun/raw_all.txt
0.8
13
nls
raw
inputs/raw_target_500frames.txt
rerun/nls_60
500
50
500
50
0
y
60
13
mle
inputs/raw_target_500frames.txt
rerun/mle_60
500
500
0
y
60
-1
0
'@
    $answers | & $programPath
    if ($LASTEXITCODE -ne 0) { throw 'Program failed' }
    if (!(Test-Path rerun/nls_60/forcefield_params.csv) -or !(Test-Path rerun/mle_60/forcefield_params.csv)) {
        throw 'Expected fitting outputs were not generated'
    }
    Write-Output 'Quickstart completed. Compare rerun with expected.'
} finally { Pop-Location }
