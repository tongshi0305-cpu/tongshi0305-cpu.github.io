#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo 'Usage: bash run_quickstart.sh /absolute/path/to/PolymerFFKit'
  exit 2
fi
EXE="$(realpath "$1")"
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/quickstart"
mkdir -p rerun
"$EXE" <<'ANSWERS'
1
11
CG
inputs/HTPB_cis_AA_500frames.xyz
100
inputs/mapping_HTPB_cis.json
1
rerun/HTPB_cis_COM.xyz
12
rerun/HTPB_cis_COM.xyz
rerun/raw_all.txt
0.8
13
nls
raw
inputs/raw_target_500frames.txt
rerun/nls_60
500
50
500
50
0
y
60
13
mle
inputs/raw_target_500frames.txt
rerun/mle_60
500
500
0
y
60
-1
0
ANSWERS
test -s rerun/nls_60/forcefield_params.csv
test -s rerun/mle_60/forcefield_params.csv
echo 'Quickstart completed. Compare rerun with expected.'
