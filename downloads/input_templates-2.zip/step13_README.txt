Step 13 Input Data Format
==========================

The CSV file should contain binned frequency data generated from Step 12's raw analysis output.

Format:
- First column: bin center values (e.g., 0.300, 0.325, ... for bond lengths in nm)
- Second column: frequency counts for the first bond/angle/dihedral type
- Third column: frequency counts for the second type (if applicable)
- Continue alternating bin_center and frequency columns for each geometric parameter

The column names starting with 'bond_', 'angle_', or 'dihedral_' are automatically detected.
The preceding column is used as the bin center.

Note: The raw_analysis.txt from Step 12 contains raw measurement values.
You need to bin these values into a histogram before using them in Step 13.
A binning script or spreadsheet can be used for this preprocessing step.

Example binning (Python):
  import numpy as np
  values = [float(x) for x in raw_data.split(',')]
  hist, bin_edges = numpy.histogram(values, bins=20)
  bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
